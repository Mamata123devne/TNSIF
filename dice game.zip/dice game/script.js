document.getElementById("rollBtn").addEventListener("click", function() {
    let scores = [];

    for (let i = 1; i <= 4; i++) {
        let playerName = document.getElementById(`p${i}name`).value.trim();
        if (playerName === "") playerName = `Player ${i}`;

        document.getElementById(`p${i}display`).textContent = playerName;

        let roll = Math.floor(Math.random() * 6) + 1;
        document.getElementById(`p${i}dice`).textContent = roll;
        document.getElementById(`p${i}total`).textContent = "Total: " + roll;

        scores.push({ name: playerName, score: roll });
    }

    let maxScore = Math.max(...scores.map(p => p.score));
    let winners = scores.filter(p => p.score === maxScore).map(p => p.name);

    let resultText = winners.length > 1 ? `It's a Tie: ${winners.join(', ')}` : `${winners[0]} Wins!`;
    document.getElementById("result").textContent = resultText;

    let popupMessage = winners.length > 1 ? `🎉 It's a Tie! 🎉\n${winners.join(', ')}` : `🎊 Congratulations ${winners[0]}! 🎊\nYou Won 🎉`;
    showPopup(popupMessage);
});

function showPopup(message) {
    document.getElementById("winnerMessage").textContent = message;
    document.getElementById("winnerPopup").style.display = "block";
}

function closePopup() {
    document.getElementById("winnerPopup").style.display = "none";
}
